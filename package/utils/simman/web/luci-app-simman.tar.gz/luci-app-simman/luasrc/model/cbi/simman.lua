--
--

require 'luci.sys'

function split(text, delim)
    -- returns an array of fields based on text and delimiter (one character only)
    local result = {}
    local magic = "().%+-*?[]^$"

    if delim == nil then
        delim = "%s"
    elseif string.find(delim, magic, 1, true) then
        -- escape magic
        delim = "%"..delim
    end

    local pattern = "[^"..delim.."]+"
    for w in string.gmatch(text, pattern) do
        table.insert(result, w)
    end
    return result
end

m = Map("simman", "Simman", translate("SIM manager for 3g modem"))

--- General settings ---
section_gen = m:section(NamedSection, "core", "simman", translate("General settings"))  -- create general section

enabled = section_gen:option(Flag, "enabled", translate("Enabled"), translate("Enable Simman"), translate("Enabled"))  -- create enable checkbox
  enabled.rmempty = false

retry_num = section_gen:option(Value, "retry_num",  translate("Number of failed attempts"))
  retry_num.default = 3
  retry_num.datatype = "and(uinteger, min(1))"
  retry_num.rmempty = false
  retry_num.optional = false

check_period = section_gen:option(Value, "check_period",  translate("Period of check, sec"))
  check_period.default = 60
  check_period.datatype = "and(uinteger, min(30))"
  check_period.rmempty = false
  check_period.optional = false

delay = section_gen:option(Value, "delay",  translate("Return to priority SIM, sec"))
  delay.default = 600
  delay.datatype = "and(uinteger, min(60))"
  delay.rmempty = false
  delay.optional = false

atdevice = section_gen:option(Value, "atdevice",  translate("AT modem device name"))
  atdevice.default = "/dev/ttyACM3"
  atdevice.datatype = "device"
  atdevice.rmempty = false
  atdevice.optional = false

testip = section_gen:option(DynamicList, "testip",  translate("IP address of remote servers"))
  testip.datatype = "ipaddr"
  testip.cast = "string"

--- SIM1 settings ---
sim = m:section(TypedSection, "sim0", translate("SIM1 settings"))
  sim.addremove = false
  sim.anonymous = true

priority = sim:option(ListValue, "priority", translate("Priority"))
  priority.default = "1"
  priority:value("0", "low")
  priority:value("1", "high")
  priority.optional = false

GPRS_apn = sim:option(Value, "GPRS_apn", translate("APN"))
  GPRS_apn.default  = ""
  GPRS_apn.rmempty = true
  GPRS_apn.optional = false
  GPRS_apn.cast = "string"

pin = sim:option(Value, "pin", translate("Pincode"))
  pin.default  = ""
  pin.rmempty = true
  pin.optional = false

GPRS_user = sim:option(Value, "GPRS_user", translate("User name"))
  GPRS_user.default  = ""
  GPRS_user.rmempty = true 
  GPRS_user.optional = false

GPRS_pass = sim:option(Value, "GPRS_pass", translate("Password"))
  GPRS_pass.default  = ""
  GPRS_pass.rmempty = true
  GPRS_pass.optional = false

--- SIM2 settings ---
sim = m:section(TypedSection, "sim1", translate("SIM2 settings"))
  sim.addremove = false
  sim.anonymous = true

priority = sim:option(ListValue, "priority", translate("Priority"))
  priority.default = "0"
  priority:value("0", "low")
  priority:value("1", "high")
  priority.optional = false

GPRS_apn = sim:option(Value, "GPRS_apn", translate("APN"))
  GPRS_apn.default  = ""
  GPRS_apn.rmempty = true
  GPRS_apn.optional = false
  GPRS_apn.cast = "string"

pin = sim:option(Value, "pin", translate("Pincode"))
  pin.default  = ""
  pin.rmempty = true
  pin.optional = false

GPRS_user = sim:option(Value, "GPRS_user", translate("User name"))
  GPRS_user.default  = ""
  GPRS_user.rmempty = true
  GPRS_user.optional = false

GPRS_pass = sim:option(Value, "GPRS_pass", translate("Password"))
  GPRS_pass.default  = ""
  GPRS_pass.rmempty = true
  GPRS_pass.optional = false

function m.on_commit(self)
  -- Modified configurations got committed and the CBI is about to restart associated services
end

function m.on_init(self)
  -- The CBI is about to render the Map object
end

return m
